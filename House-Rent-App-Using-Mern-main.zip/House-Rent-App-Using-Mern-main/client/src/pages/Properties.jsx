// client/src/pages/Properties.jsx
import React from "react";

const Properties = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Properties Listing</h1>
      <p>This page will show a list of all properties available for rent.</p>
      {/* TODO: Fetch and display properties from backend */}
    </div>
  );
};

export default Properties;
